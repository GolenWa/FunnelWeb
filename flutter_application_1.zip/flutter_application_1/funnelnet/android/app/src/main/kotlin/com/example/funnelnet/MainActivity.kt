package com.example.funnelnet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
